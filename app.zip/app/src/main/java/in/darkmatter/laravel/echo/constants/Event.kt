package `in`.darkmatter.laravel.echo.constants

object Event {
    const val UNSUBSCRIBE ="unsubscribe"
    const val CONNECT = "connect"
    const val RECONNECT = "reconnect"
    const val SUBSCRIBE  =  "subscribe"
    const val CLIENT_EVENT  = "client event"
}