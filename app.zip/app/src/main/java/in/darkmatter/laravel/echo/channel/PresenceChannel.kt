package `in`.darkmatter.laravel.echo.channel

interface PresenceChannel {
    fun here(callback:(data:Any)->Unit):PresenceChannel
    fun joining(callback:(data:Any)->Unit):PresenceChannel
    fun leaving(callback:(data:Any)->Unit) :PresenceChannel
}