package `in`.darkmatter.laravel.echo.connector

enum class Broadcaster {
    SOCKET_IO, PUSHER
}