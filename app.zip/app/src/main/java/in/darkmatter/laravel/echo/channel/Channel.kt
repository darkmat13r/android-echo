package `in`.darkmatter.laravel.echo.channel

abstract class Channel {
    abstract fun listen(event: String, callback: (data:Any) -> Unit): Channel
    abstract fun stopListening(event: String): Channel

}