package `in`.darkmatter.laravel.echo.channel

import `in`.darkmatter.laravel.echo.connector.Connector
import `in`.darkmatter.laravel.echo.constants.Event
import `in`.darkmatter.laravel.echo.util.EventFormatter
import android.util.Log
import com.github.nkzawa.emitter.Emitter
import com.github.nkzawa.socketio.client.Socket

open class SocketIOChannel(
    private val socket: Socket,
    private val name: String,
    private val options: Connector.Options
) : Channel() {

    companion object{
        private val TAG = SocketIOChannel::class.java.simpleName
    }
    private var eventFormatter: EventFormatter = EventFormatter(options.namespace)
    var events = hashMapOf<String, Emitter.Listener>()
    init {
        options.channel = name
        this.subscribe()
        this.configureReconnector()
    }




    /**
     * Subscribe to a Socket.io channel
     */
    fun subscribe() {
        Log.e(TAG,"Subscribing")
        this.socket.emit(Event.SUBSCRIBE, options)
    }

    /**
     * Unsubscribe to a Socket.io channel and unbind event callback
     */
    fun unsubscribe() {
        unbind()
        this.socket.emit(Event.UNSUBSCRIBE,options)
        this.socket.disconnect()
    }

    /**
     * Listen for an event on the channel instance
     */
    override fun listen(event: String, callback: (data: Any) -> Unit): SocketIOChannel {
        this.on(event, callback)
        return this
    }

    /**
     * Stop listening for an event on the channel instance
     */
    override fun stopListening(event: String): SocketIOChannel {
        val name = this.eventFormatter.format(event)
        this.socket.off(name)
        this.events.remove(name)
        return this
    }

    /**
     * Bind the channel's socket to an event and store the callback
     */
    fun on(event: String, callback: (data: Any) -> Unit) {
        val listener = Emitter.Listener {
            callback(it)
        }
        this.socket.on(event, listener)
        this.bind(event, listener)
    }

    /**
     * Attach a reconnect listener and bind the event
     */
    fun configureReconnector() {
        val listener = Emitter.Listener {
            this.subscribe()
        }
        this.socket.on(Event.RECONNECT, listener)
        this.bind(Event.RECONNECT, listener)
    }

    /**
     * Unbind the channel's socket from all stored event callback
     */
    fun unbind() {
        events.forEach { (event, listener) ->
            this.socket.off(event, listener)
            events.remove(event)
        }
    }

    /**
     * Bind the channel's  socket to an event and store the callback
     */
    fun bind(event: String, callback: Emitter.Listener) {
        this.events[event] = callback
    }


}