package `in`.darkmatter.laravel.echo

object Config{
    const val DEFAULT_NAMESPACE = "App.Events"
}